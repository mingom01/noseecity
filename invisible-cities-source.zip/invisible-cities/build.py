from pathlib import Path
import re, json, subprocess
base=Path(__file__).resolve().parent
source=(base/'shell.html').read_text()
for token,name in [('THREE','node_modules/three/build/three.min.js'),('DATA','cities.js'),('SCENE','scene.js'),('APP','app.js')]:
    js=(base/name).read_text()
    subprocess.run(['node','--check',str(base/name)],check=True,capture_output=True,text=True)
    assert '</script' not in js.lower()
    source=source.replace('<!--'+token+'-->','<script>\n'+js+'\n</script>')
assert not re.search(r'<!--(?:THREE|DATA|SCENE|APP)-->',source)
ids=re.findall(r'\bid="([^"]+)"', (base/'shell.html').read_text())
assert len(ids)==len(set(ids)), 'Duplicate element IDs'
refs=re.findall(r"\$\('([^']+)'\)", (base/'app.js').read_text())
assert set(refs)-set(ids) <= {'chapter-start','retry-load'},set(refs)-set(ids)
license_text=(base/'node_modules/three/LICENSE').read_text()
source=source.replace('</head>','<script type="text/plain" id="three-license">\n'+license_text+'\n</script>\n</head>')
(base/'invisible-cities.html').write_text(source,encoding='utf-8')
print(json.dumps({'html_bytes':len(source.encode()),'unique_element_ids':len(ids),'js_syntax':'all passed','output':'/home/user/project/invisible-cities.html'}))
