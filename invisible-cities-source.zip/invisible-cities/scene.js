/* Original procedural architecture. Units are interpretive, not reconstructions. */
function createWorld(canvas) {
  const T=THREE, scene=new T.Scene();
  const renderer=new T.WebGLRenderer({canvas,antialias:true,alpha:false,preserveDrawingBuffer:true,powerPreference:'high-performance'});
  renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.75));
  renderer.outputColorSpace=T.SRGBColorSpace;
  renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.25;
  const camera=new T.PerspectiveCamera(36,1,.2,650);
  const night=new T.Color('#101a20'), day=new T.Color('#ddd8c9');
  scene.background=night.clone();scene.fog=new T.FogExp2(night,.004);
  scene.add(new T.HemisphereLight(0xcbdbe5,0x25323b,2));
  const sun=new T.DirectionalLight(0xffdfb0,3.4);sun.position.set(-25,45,25);scene.add(sun);
  const rim=new T.DirectionalLight(0x8fc4d8,2.2);rim.position.set(25,12,-25);scene.add(rim);
  const fill=new T.PointLight(0xe7ad65,65,60,1.5);fill.position.set(0,8,8);scene.add(fill);
  const material=(color,extra={})=>new T.MeshStandardMaterial({color,roughness:.75,metalness:.12,...extra});
  const M={ivory:material('#d1c9af'),pale:material('#e7e1c9'),sand:material('#b0a385'),dark:material('#26383e'),rock:material('#1d2b31'),gold:material('#b78b53',{metalness:.6,roughness:.4}),terra:material('#8e5543'),jade:material('#657a72'),glass:material('#9fc3bd',{transparent:true,opacity:.16,depthWrite:false,metalness:.05,roughness:.2,side:T.DoubleSide}),water:material('#335863',{transparent:true,opacity:.55,depthWrite:false,metalness:.7,roughness:.18}),lamp:new T.MeshBasicMaterial({color:'#f7d899'}),dim:new T.MeshBasicMaterial({color:'#597683',transparent:true,opacity:.4,depthWrite:false}),ghost:material('#aeb9b2',{transparent:true,opacity:.24,depthWrite:false})};
  const G={box:new T.BoxGeometry(1,1,1),cyl:new T.CylinderGeometry(1,1,1,12),cone:new T.ConeGeometry(1,1,8),sphere:new T.SphereGeometry(1,20,12),gem:new T.OctahedronGeometry(1),plane:new T.PlaneGeometry(1,1)};
  let active=null,atlas=null,currentCity=null,mode='city',wire=false,isDay=false,orbit=!matchMedia('(prefers-reduced-motion: reduce)').matches;
  let az=-.58,el=.49,dist=66,targetDist=66,focus=3,targetFocus=3,cityTime=0,elapsed=0,last=performance.now(),disposed=false;
  const mouse=new T.Vector2(),ray=new T.Raycaster(),pickables=[];let onPick=()=>{},onHover=()=>{};
  let seed=1;const rnd=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296};
  const v=(x,y,z)=>new T.Vector3(x,y,z);
  function builder(){
    const group=new T.Group(),batches=new Map(),lines=new Map(),tmp=new T.Object3D();
    function add(kind,mat,x,y,z,sx=1,sy=sx,sz=sx,rx=0,ry=0,rz=0){
      const key=kind+':'+mat; if(!batches.has(key))batches.set(key,[]);
      tmp.position.set(x,y,z);tmp.rotation.set(rx,ry,rz);tmp.scale.set(sx,sy,sz);tmp.updateMatrix();batches.get(key).push(tmp.matrix.clone());
    }
    function line(points,color='#a58c64',opacity=.5){
      const key=color+':'+opacity;if(!lines.has(key))lines.set(key,{color,opacity,p:[]});const ar=lines.get(key).p;
      for(let i=1;i<points.length;i++)ar.push(...points[i-1],...points[i]);
    }
    const box=(x,y,z,w,h,d,mat='ivory',rot=0)=>add('box',mat,x,y,z,w,h,d,0,rot,0);
    const cyl=(x,y,z,r,h,mat='ivory')=>add('cyl',mat,x,y,z,r,h,r);
    const ball=(x,y,z,r,mat='gold')=>add('sphere',mat,x,y,z,r,r,r);
    function beam(a,b,r=.07,mat='gold'){
      let A=v(...a),B=v(...b),D=B.clone().sub(A),mid=A.clone().add(B).multiplyScalar(.5);
      const key='cyl:'+mat;if(!batches.has(key))batches.set(key,[]);
      tmp.position.copy(mid);tmp.quaternion.setFromUnitVectors(v(0,1,0),D.clone().normalize());tmp.scale.set(r,D.length(),r);tmp.updateMatrix();batches.get(key).push(tmp.matrix.clone());
    }
    function ring(x,y,z,r,color='#a58c64',opacity=.45,plane='xz'){
      const p=[];for(let i=0;i<=80;i++){let a=i/80*Math.PI*2;p.push(plane==='xy'?[x+Math.cos(a)*r,y+Math.sin(a)*r,z]:plane==='yz'?[x,y+Math.sin(a)*r,z+Math.cos(a)*r]:[x+Math.cos(a)*r,y,z+Math.sin(a)*r]);}line(p,color,opacity);
    }
    function curve(points,color='#bba477',opacity=.65){const c=new T.CatmullRomCurve3(points.map(p=>v(...p)));line(c.getPoints(28).map(p=>p.toArray()),color,opacity);}
    function frame(x,y,z,w,h,d,color='#a89676',opacity=.55){
      const p=[[-1,-1,-1],[1,-1,-1],[1,-1,1],[-1,-1,1],[-1,1,-1],[1,1,-1],[1,1,1],[-1,1,1]].map(p=>[x+p[0]*w/2,y+p[1]*h/2,z+p[2]*d/2]);
      [[0,1],[1,2],[2,3],[3,0],[4,5],[5,6],[6,7],[7,4],[0,4],[1,5],[2,6],[3,7]].forEach(([a,b])=>line([p[a],p[b]],color,opacity));
    }
    function house(x,y,z,w=1.5,h=2,d=1.5,mat='ivory',roof=true){
      box(x,y+h/2,z,w,h,d,mat);
      if(roof)add('cone',mat==='dark'?'rock':'sand',x,y+h+.45,z,w*.79,.95,d*.79,0,Math.PI/4,0);
      if(mat!=='ghost'&&mat!=='rock'){
        const n=Math.max(1,Math.min(5,Math.floor(h/1.05)));
        for(let j=0;j<n;j++){box(x,y+.5+j*.93,z+d/2+.012,.15,.25,.023,'lamp');if(w>1.4)box(x+w/2+.012,y+.5+j*.93,z,.023,.24,.15,'lamp');}
      }
    }
    function tower(x,z,h=8,r=1,y=0,mat='ivory'){cyl(x,y+h/2,z,r,h,mat);cyl(x,y+h,z,r*1.13,.28,'gold');add('cone','sand',x,y+h+r*.7,z,r*1.22,r*1.7,r*1.22);for(let k=1;k<h;k+=2)box(x,y+k,z+r,.13,.32,.03,'lamp');}
    function arch(x,y,z,w=2.5,h=3,mat='ivory',rot=0){
      const a=[Math.cos(rot),Math.sin(rot)],put=(dx,dy,dz,ww,hh,dd)=>box(x+dx*a[0]+dz*a[1],y+dy,z-dx*a[1]+dz*a[0],ww,hh,dd,mat,rot);
      put(-w/2,h*.31,0,.24,h*.62,.38);put(w/2,h*.31,0,.24,h*.62,.38);
      const pts=[];for(let i=0;i<=18;i++){let t=i/18*Math.PI,xx=Math.cos(t)*w/2,yy=h*.62+Math.sin(t)*h*.38;pts.push([x+xx*a[0],y+yy,z-xx*a[1]]);}for(let i=1;i<pts.length;i++)beam(pts[i-1],pts[i],.15,mat);
    }
    function bridge(a,b,w=.8,mat='sand'){const A=v(...a),B=v(...b),mid=A.clone().add(B).multiplyScalar(.5),L=A.distanceTo(B);box(mid.x,mid.y,mid.z,w,.16,L,mat,Math.atan2(B.x-A.x,B.z-A.z));beam([a[0],a[1]+.6,a[2]],[b[0],b[1]+.6,b[2]],.025,'gold');}
    function island(x=0,y=-1.5,z=0,r=12,mat='rock'){
      cyl(x,y,z,r,.65,mat);add('cone',mat,x,y-r*.33,z,r,r*.72,r,0,0,Math.PI);
      ring(x,y+.36,z,r,'#81989a',.17);
    }
    function tree(x,y,z,h=2){cyl(x,y+h*.28,z,.055,h*.58,'gold');add('cone','jade',x,y+h*.65,z,h*.36,h,h*.36);}
    function grid(n=6,step=3,y=0,fn){for(let i=0;i<n;i++)for(let j=0;j<n;j++){const x=(i-(n-1)/2)*step,z=(j-(n-1)/2)*step;fn(x,z,i,j,y);}}
    function absorb(source,matrix,theme){
      const instance=new T.Matrix4(),point=new T.Vector3();
      source.traverse(o=>{
        if(o.isInstancedMesh){const key=o.userData.batchKey;if(!batches.has(key))batches.set(key,[]);const arr=batches.get(key);for(let i=0;i<o.count;i++){o.getMatrixAt(i,instance);const m=matrix.clone().multiply(instance);m.theme=theme;arr.push(m);}}
        else if(o.isLine){const a=o.geometry.attributes.position,key='#'+o.material.color.getHexString()+':'+o.material.opacity;if(!lines.has(key))lines.set(key,{color:o.material.color.clone(),opacity:o.material.opacity*.8,p:[]});const pts=lines.get(key).p;for(let i=0;i<a.count;i++){point.fromBufferAttribute(a,i).applyMatrix4(matrix);pts.push(point.x,point.y,point.z);}}
      });
    }
    function finish(){
      for(const [key,arr]of batches){const[kind,mat]=key.split(':');const mesh=new T.InstancedMesh(G[kind],M[mat],arr.length);arr.forEach((m,i)=>mesh.setMatrixAt(i,m));mesh.userData.batchKey=key;mesh.userData.themes=arr.map(m=>m.theme??-1);mesh.instanceMatrix.needsUpdate=true;mesh.frustumCulled=false;group.add(mesh);}
      for(const {color,opacity,p}of lines.values()){const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(p,3));const lm=new T.LineBasicMaterial({color,transparent:true,opacity,depthWrite:false});group.add(new T.LineSegments(geo,lm));}
      return group;
    }
    return{group,add,box,cyl,ball,beam,line,ring,curve,frame,house,tower,arch,bridge,island,tree,grid,absorb,finish};
  }
  const geometrySet=new Set(Object.values(G));
  function release(group){if(!group)return;scene.remove(group);group.traverse(o=>{if(o.geometry&&!geometrySet.has(o.geometry))o.geometry.dispose();if(o.isLine&&o.material)o.material.dispose();if(o.isInstancedMesh)o.dispose();});}
  function city(c,miniature=false){
    seed=20261+c.id*317;const b=builder(),{add,box,cyl,ball,beam,line,ring,curve,frame,house,tower,arch,bridge,island,tree,grid}=b;
    const circle=(n,r,fn)=>{for(let i=0;i<n;i++){let a=i/n*Math.PI*2;fn(Math.cos(a)*r,Math.sin(a)*r,a,i);}};
    if(!['Octavia','Baucis','Valdrada','Argia','Eusapia','Laudomia'].includes(c.name))island(0,-1.1,0,c.name==='Cecilia'?19:14);
    switch(c.name){
      case'Diomira':
        // Sixty domes, rendered as architecture rather than a quoted description.
        grid(8,3.05,0,(x,z,i,j)=>{if((i===0||i===7)&&(j===0||j===7))return;let h=1.2+rnd()*3.4;house(x,0,z,1.8,h,1.8,'ivory',false);ball(x,h,z,.99,'pale');cyl(x,h+.85,z,.025,.7,'gold');});tower(0,0,10,1.25);break;
      case'Isidora':
        cyl(0,6,0,2,12,'ivory');for(let i=0;i<110;i++){let a=i*.2,y=i*.14;box(Math.cos(a)*3.1,y,Math.sin(a)*3.1,1.4,.15,.65,'sand',-a);beam([Math.cos(a)*3.8,y+.65,Math.sin(a)*3.8],[Math.cos(a+.2)*3.8,y+.79,Math.sin(a+.2)*3.8],.025);}circle(14,10,(x,z,a)=>house(x,0,z,2,2.3+rnd()*2,2));ring(0,.05,0,7);break;
      case'Dorothea':
        box(0,0,0,27,.2,2.8,'water');box(0,.01,0,2.8,.2,27,'water');[-1,1].forEach(s=>[-1,1].forEach(t=>{for(let i=0;i<10;i++){let x=s*(3+rnd()*8),z=t*(3+rnd()*8);house(x,0,z,1.4,2+rnd()*4,1.6);}tower(s*11,t*11,7,.8);}));for(let d=-8;d<=8;d+=4){bridge([-2,.5,d],[2,.5,d],1.2);bridge([d,.5,-2],[d,.5,2],1.2);}break;
      case'Zaira':
        grid(6,3.7,0,(x,z)=>{let h=1+rnd()*6;house(x,0,z,1.7,h,1.7);curve([[x,h,z],[x*.3,h+2,z*.4],[0,1,0]],'#a89b7d',.35);});for(let i=0;i<14;i++)box(-9+i*.8,i*.24,9,1,.24,2,'sand');break;
      case'Anastasia':
        circle(20,10,(x,z,a)=>{house(x,0,z,2,3,2,'sand',false);box(x,3.5,z,2.2,.18,2.2,'gold',a);});add('gem','gold',0,5,0,3.2,5,3.2);ring(0,2,0,7);ring(0,6,0,6);circle(12,7,(x,z)=>beam([x,0,z],[0,8,0],.025));break;
      case'Tamara':
        grid(6,3.7,0,(x,z,i,j)=>{house(x,0,z,1.8,1.4+rnd()*2,1.8,'sand');cyl(x,5,z,.045,5,'gold');if((i+j)%3===0)add('gem','gold',x,8,z,.7,.7,.25);else if((i+j)%3===1)ring(x,7.5,z,.7,'#dfc394',.9,'xy');else frame(x,7.5,z,1.2,1.2,.12);});break;
      case'Zora':
        grid(9,2.5,0,(x,z,i,j)=>{if(Math.abs(x)+Math.abs(z)<7){frame(x,1.5,z,1.3,3,1.3,'#94a6a4',.3);return;}house(x,0,z,1.3,3,1.3);});ring(0,0,0,5);break;
      case'Despina':
        box(-7,-.45,0,13,.22,23,'water');for(let i=0;i<11;i++){const p=[];for(let j=0;j<30;j++)p.push([1+i,-.1+Math.sin(j*.23+i*.7)*.45,(j-15)*.8]);line(p,'#b2a07c',.45);}circle(14,7,(x,z,a)=>{tower(x,z,2.3+rnd()*4,.6);});for(let i=0;i<4;i++){let x=-9+i*3;beam([x,0,0],[x,10,0],.055);add('cone','pale',x+1.4,6,0,2.2,5,.04,0,0,.18);}break;
      case'Zirma':
        circle(12,9,(x,z)=>tower(x,z,6,.85));ring(0,6,0,9,'#d8bb82',.8);ring(0,7.3,0,9,'#d8bb82',.4);for(let i=0;i<5;i++)box(-6+i*3,6.8,0,2,.8,1.2,'terra');bridge([-12,6,0],[12,6,0],1.1);break;
      case'Isaura':
        grid(6,3.8,0,(x,z)=>{cyl(x,.5,z,.7,1,'sand');cyl(x,.65,z,.46,.8,'dark');beam([x,1,z],[x,7+rnd()*3,z],.08,'gold');frame(x,2,z,1.8,3,1.8);line([[x,0,z],[x,-5,z]],'#78abb3',.8);});cyl(0,-4,0,10,.15,'water');break;
      case'Maurilia':
        for(let i=0;i<35;i++){let z=(rnd()-.5)*20,x=2+rnd()*9;house(-x,0,z,1.4,1.3+rnd()*2,1.3,'sand');house(x,0,z,1.7,5+rnd()*5,1.4,'ivory',false);}frame(0,5,0,.2,12,24,'#d1b784',.85);break;
      case'Fedora':
        cyl(0,2,0,3.5,4,'ivory');ball(0,5,0,4,'glass');circle(8,9,(x,z,a,i)=>{cyl(x,.6,z,2,.8,'sand');ball(x,3.4,z,2.6,'glass');for(let k=0;k<5;k++){let dx=(rnd()-.5)*2.3,dz=(rnd()-.5)*2.3;house(x+dx,1,z+dz,.55,.8+rnd()*2,.5,i%2?'pale':'gold',false);}ring(x,3.4,z,2.6,'#9bc3c0',.38,'xy');});break;
      case'Zoe':
        grid(6,3.3,0,(x,z,i,j)=>{let h=2+(i+j)%3*1.6;box(x,h/2,z,2.6,h,2.6,'ivory');arch(x,0,z+1.31,1.4,1.8,'gold');if(i<5)bridge([x,h-.5,z],[x+3.3,h-.5,z],.7);});break;
      case'Zenobia':
        grid(5,4.4,0,(x,z,i,j)=>{let h=4+(i+j)%3*3;for(let dx of[-.8,.8])for(let dz of[-.8,.8])beam([x+dx,-1,z+dz],[x+dx,h,z+dz],.055,'gold');box(x,h,z,3,.16,3,'sand');house(x,h,z,1.8,1.8,1.8);if(i<4)bridge([x,h,z],[x+4.4,h,z],.6);for(let k=0;k<8;k++)box(x+1.1,h-k*.45,z+1.7,.8,.08,.08,'gold');});break;
      case'Euphemia':
        circle(16,8,(x,z,a,i)=>{cyl(x,1.1,z,.05,2.2,'gold');add('cone',i%2?'terra':'sand',x,2.4,z,1.8,1.3,1.8,0,a,0);box(x,.45,z,1.5,.4,1,'ivory');curve([[x,.8,z],[x*.3,2,z*.3],[-x,.8,-z]],'#bc9c62',.4);});cyl(0,.2,0,2,.4,'gold');break;
      case'Zobeide':
        for(let r=3;r<=12;r+=2.1){for(let i=0;i<16;i++){if((i+Math.round(r))%5===0)continue;let a=i/16*Math.PI*2;box(Math.cos(a)*r,1.3,Math.sin(a)*r,.35,2.6,r*.43,'pale',-a);}}ring(0,0,0,1.5,'#eacb96',.65);break;
      case'Hypatia':
        circle(12,8,(x,z,a,i)=>{arch(x,0,z,2.5,4,'ivory',a);add('cone','gold',x,6,z,1.1,3,1.1,Math.PI,0,0);});for(let i=0;i<18;i++)box(-5+i*.55,i*.4,0,.8,.2,3,'sand');arch(0,8,0,4,4,'gold',Math.PI/2);break;
      case'Armilla':
        grid(6,3.7,0,(x,z,i,j)=>{let h=2+rnd()*8;beam([x,0,z],[x,h,z],.075,'gold');beam([x,h,z],[x+1.2,h,z],.075,'gold');ball(x,h,z,.16,'gold');cyl(x+1.2,h-.3,z,.44,.3,'pale');line([[x+1.2,h-.5,z],[x+1.2,0,z]],'#8abec3',.7);if(i<5)beam([x,2,z],[x+3.7,2,z],.045);if(j<5)beam([x,4,z],[x,4,z+3.7],.045);});break;
      case'Chloe':
        circle(32,10,(x,z,a,i)=>{cyl(x,.7,z,.15,1.3,i%3?'ivory':'gold');ball(x,1.55,z,.22,'lamp');if(i%2===0)curve([[x,1,z],[0,3+rnd()*4,0],[Math.cos(a+2.3)*10,1,Math.sin(a+2.3)*10]],'#c7b084',.35);});circle(12,13,(x,z,a)=>arch(x,0,z,2,4,'sand',a));break;
      case'Valdrada':
        cyl(0,-.1,0,15,.15,'water');grid(5,4,0,(x,z)=>{let h=2+rnd()*5;house(x,.4,z,2,h,2);box(x,-h/2-.5,z,2,h,2,'ghost');add('cone','ghost',x,-h-.8,z,1.5,1,1.5,Math.PI,Math.PI/4,0);beam([x,h,z],[x,-h,z],.013,'gold');});ring(0,0,0,15,'#8bb2bd',.5);break;
      case'Olivia':
        for(let i=0;i<11;i++){let x=(i-5)*2.2;arch(x,0,7,2,5,'pale');house(x,0,9,1.8,6,2,'ivory',false);cyl(x,5,-5,.5,10+rnd()*3,'dark');box(x,1.5,-4,2,3,7,'sand');beam([x,4,-5],[x+1,4,3],.15,'gold');}break;
      case'Sophronia':
        ring(-5,6,0,5,'#c7aa72',.9,'xy');ring(-5,6,0,4.8,'#c7aa72',.55,'xy');for(let i=0;i<16;i++){let a=i/16*Math.PI*2,x=-5+Math.cos(a)*5,y=6+Math.sin(a)*5;beam([-5,6,0],[x,y,0],.025);box(x,y-.5,0,.6,.8,.6,'terra');}beam([-8,0,1],[-5,6,0],.12);beam([-2,0,1],[-5,6,0],.12);for(let i=0;i<7;i++){let z=(i-3)*3;house(7,1+rnd()*6,z,2,3,2,'pale',false);frame(7,0,z,2,1,2);}break;
      case'Eutropia':
        circle(6,8,(x,z,a)=>{cyl(x,0,z,3,.3,'sand');for(let j=0;j<5;j++){let t=j/5*6.28;house(x+Math.cos(t)*1.6,.1,z+Math.sin(t)*1.6,.8,1.8,.8);}curve([[x,.4,z],[0,2,0],[-x,.4,-z]],'#b8b386',.45);});break;
      case'Zemrude':
        for(let i=0;i<10;i++){let z=(i-4.5)*2.7;[-1,1].forEach(s=>{house(s*4,0,z,3,3,2,'dark',false);house(s*4,3,z,3,4+rnd()*3,2,'pale');arch(s*4,3,z+1.1,1.7,2,'gold');});}box(0,0,0,2,.1,26,'water');break;
      case'Aglaura':
        frame(0,6,0,21,12,21,'#d0b17a',.85);grid(5,3.5,0,(x,z)=>house(x+rnd(),0,z+rnd(),1+rnd(),1+rnd()*6,1.5));for(let k=0;k<4;k++)ring(0,k*3,0,14,'#8a9b98',.16);break;
      case'Octavia':{
        [-1,1].forEach(s=>{island(s*16,-5,0,5);box(s*16,1,0,3,12,5,'rock');for(let j=-1;j<=1;j++)tower(s*15,j*4,12,.42,-1,'sand');});
        const sag=x=>2+5*(x/15)**2;
        for(let z=-7;z<=7;z+=1.4){const p=[];for(let x=-15;x<=15;x+=.6)p.push([x,sag(x),z]);line(p,'#c3a576',.8);}
        for(let x=-15;x<=15;x+=1.5)line([[x,sag(x),-7],[x,sag(x),7]],'#9b9d8c',.5);
        for(let i=0;i<32;i++){let x=(rnd()-.5)*24,z=(rnd()-.5)*12,h=1.2+rnd()*2.3,y=sag(x)-2-rnd()*4;house(x,y-h,z,1.1,h,1.1,i%5?'ivory':'terra',false);for(let d of[-.45,.45])beam([x+d,y,z],[x+d,sag(x),z],.025);add('cone','sand',x,y-h-.45,z,.82,.9,.82,Math.PI,Math.PI/4,0);for(let k=0;k<6;k++)box(x+.8,y-h-k*.4,z,.6,.06,.06,'gold');}
        for(let x of[-15,15])for(let z of[-7,7])beam([x,10,z*.6],[0,2,z],.06,'gold');
        bridge([-16,7,0],[16,7,0],.7,'sand');break;}
      case'Ersilia':{
        const pts=[];circle(22,11,(x,z,a,i)=>{let y=2+rnd()*7;pts.push([x,y,z]);beam([x,0,z],[x,y,z],.035);if(i%4===0)house(x,0,z,1.6,1.6,1.6,'ghost');});for(let i=0;i<pts.length;i++)for(let j=i+1;j<pts.length;j++)if(rnd()>.55)line([pts[i],pts[j]],['#ccaf7b','#81989d','#d4cfc0'][j%3],.4);break;}
      case'Baucis':
        island(0,-2,0,13);circle(7,7,(x,z,a,i)=>{let h=15+(i%3)*3;for(let dx of[-.75,.75])for(let dz of[-.75,.75])beam([x+dx,-2,z+dz],[x+dx,h,z+dz],.065,'gold');box(x,h,z,3.3,.25,3.3,'sand');house(x,h,z,2,2.7,2);tree(x+1.5,h,z,2.2);if(i<6){let aa=a+Math.PI*2/7;bridge([x,h,z],[Math.cos(aa)*7,h,Math.sin(aa)*7],.6);}beam([x,h,z],[x*.8,-1,z*.8],.012,'gold');});for(let i=0;i<20;i++)tree((rnd()-.5)*15,-1,(rnd()-.5)*15,.4+rnd());break;
      case'Leandra':
        circle(12,9,(x,z,a)=>{house(x,0,z,2.3,3,2.3);ball(x,2,z+.9,.19,'lamp');ball(x*.77,.5,z*.77,.14,'lamp');curve([[x,2,z],[x*.6,3,z*.6],[x*.3,.8,z*.3]],'#c3a77d',.3);});house(0,0,0,4,5,4,'sand');break;
      case'Melania':
        for(let r=4;r<=12;r+=2.5)circle(Math.round(r*3),r,(x,z,a,i)=>{box(x,.4,z,.6,.8,.6,'sand');cyl(x,1.1,z,.14,.65,'ivory');ball(x,1.65,z,.2,i%7?'ivory':'lamp');});cyl(0,.3,0,2.5,.6,'gold');arch(0,.5,0,3,4);break;
      case'Esmeralda':
        for(let i=-2;i<=2;i++){box(i*4,-.1,0,1.4,.2,26,'water');box(0,.15,i*4,26,.2,.9,'water');bridge([-12,2.3,i*4+1],[12,2.3,i*4+1],.55);bridge([i*4+1,4.5,-12],[i*4+1,4.5,12],.5);}grid(5,4,0,(x,z)=>house(x+1.7,0,z+1.7,1.2,2+rnd()*5,1.2));break;
      case'Phyllis':
        circle(18,10,(x,z,a,i)=>{house(x,0,z,2,2+rnd()*5,1.8);arch(x,0,z,1.4,2+rnd()*2,'gold',a);});const path=[];for(let i=0;i<35;i++){let a=i*.38;path.push([Math.cos(a)*(2+i*.2),.35,Math.sin(a)*(2+i*.2)]);}curve(path,'#f7d296',.95);break;
      case'Pyrrha':
        circle(8,10,(x,z)=>{frame(x,2.5,z,3,5,3,'#9cb1ae',.4);house(x,0,z,2.5,4,2.5,'ghost');});grid(3,2.8,0,(x,z)=>house(x,0,z,1.7,2+rnd()*4,1.7));break;
      case'Adelma':
        box(0,-.5,0,26,.2,21,'water');for(let s of[-1,1])for(let i=0;i<9;i++){let z=(i-4)*2.5;house(s*9,0,z,2,3+rnd()*4,2,'dark');ball(s*6.5,1,z,.2,'lamp');cyl(s*6.5,.45,z,.13,.9,'ghost');}for(let i=0;i<6;i++){box(-3+i*1.3,.1,2+i*1.3,.75,.4,2.2,'sand',.2);beam([-3+i*1.3,.1,2+i*1.3],[-3+i*1.3,3,2+i*1.3],.035);}break;
      case'Eudoxia':
        for(let i=-6;i<=6;i++){line([[-12,.05,i*2],[12,.05,i*2]],i%2?'#ceaf75':'#955744',.9);line([[i*2,.05,-12],[i*2,.05,12]],i%2?'#ceaf75':'#955744',.9);}for(let i=0;i<50;i++){let x=(rnd()-.5)*20,z=(rnd()-.5)*20;house(x,.4,z,1.2,1+rnd()*7,1.1,'ivory');}ring(0,.2,0,9,'#e2c185',.7);break;
      case'Moriana':
        for(let i=0;i<14;i++){let x=(i-6.5)*1.8,h=3+rnd()*7;house(x,0,1,1.6,h,1.5,'pale');arch(x,0,2,1.3,2.8,'gold');for(let j=0;j<5;j++)add('gem',j%2?'dark':'rock',x+(rnd()-.5),rnd()*3,-2-rnd()*4,.8,rnd()*3+.4,.6);}frame(0,6,0,27,12,.1,'#b4a88f',.4);break;
      case'Clarice':
        grid(6,3.5,0,(x,z,i,j)=>{let h=1+rnd()*5;box(x,h/2,z,2,h,2,'sand');if((i+j)%2===0)arch(x,h,z,1.8,2,'pale');else add('cyl','pale',x,h+.5,z,.5,2,.5,0,0,Math.PI/2);box(x,h+2.5,z,1.3,.3,1.3,'gold');});break;
      case'Eusapia':
        cyl(0,-.2,0,14,.25,'glass');grid(5,4,0,(x,z,i,j)=>{let h=2+(i+j)%3;house(x,0,z,2,h,2,'ivory');house(x,-9,z,2,h,2,'ghost');line([[x,0,z],[x,-9,z]],'#9fb5b2',.3);});island(0,-10,0,14);break;
      case'Beersheba':
        grid(5,3.4,0,(x,z)=>house(x,0,z,1.8,2.4,1.8,'pale'));for(let i=0;i<50;i++){let a=rnd()*6.28,r=rnd()*10;add('gem',i%3?'gold':'sand',Math.cos(a)*r,10+rnd()*4,Math.sin(a)*r,.3+rnd(),.3+rnd(),.3+rnd());}ring(0,11,0,11,'#c9b681',.4);beam([0,0,0],[0,15,0],.03);break;
      case'Leonia':
        grid(5,2.8,0,(x,z)=>house(x,0,z,1.6,2+rnd()*3,1.6,'pale',false));for(let i=0;i<260;i++){let a=rnd()*6.28,r=9+rnd()*4;add('gem',i%3?'rock':'sand',Math.cos(a)*r,rnd()*5,Math.sin(a)*r,.4+rnd(),.4+rnd()*1.6,.4+rnd());}break;
      case'Irene':
        for(let i=0;i<100;i++){let a=rnd()*6.28,r=Math.sqrt(rnd())*11;house(Math.cos(a)*r,-.3,Math.sin(a)*r,.45,.5+rnd()*1.4,.45,'sand',false);}circle(20,13,(x,z,a,i)=>add('cone','rock',x,1,z,2,4+rnd()*4,2));ring(0,0,0,10,'#d0b483',.25);break;
      case'Argia':
        island(0,-4,0,14);cyl(0,-.5,0,13,6,'glass');grid(5,4.2,0,(x,z)=>{house(x,-3,z,2,2.3+rnd()*3,2,'sand');frame(x,-1,z,2.2,3.5,2.2,'#b29e7e',.35);});for(let y=-3;y<=2;y+=1.25)ring(0,y,0,13,'#7c8b80',.3);break;
      case'Thekla':
        grid(5,4,0,(x,z)=>{let h=3+rnd()*9;frame(x,h/2,z,2.3,h,2.3,'#c0b29b',.65);for(let y=0;y<h;y+=2)box(x,y,z,2.3,.12,2.3,'sand');});[-7,7].forEach(x=>{beam([x,0,0],[x,16,0],.12);beam([x-5,16,0],[x+5,16,0],.1);line([[x+4,16,0],[x+4,8,0]],'#e0bc80',.8);});circle(12,10,(x,z,a,i)=>{ball(x,19+Math.sin(a*3),z,.11,'lamp');line([[x,19+Math.sin(a*3),z],[Math.cos(a+.53)*10,19+Math.sin((a+.53)*3),Math.sin(a+.53)*10]],'#88a9b9',.4);});break;
      case'Trude':
        grid(8,3,0,(x,z,i,j)=>{if(j===3||j===4)return;house(x,0,z,1.8,3,1.8,'sand',false);});box(0,-.2,0,26,.1,4,'dark');for(let i=-12;i<12;i+=2)box(i,-.1,0,.8,.03,.08,'lamp');break;
      case'Olinda':
        for(let k=0;k<5;k++){let r=1.5+k*2.5;ring(0,.1,0,r,'#b7bf98',.65);circle(5+k*7,r,(x,z,a,i)=>house(x,0,z,.7+k*.12,4-k*.6,.7+k*.1,k%2?'sand':'ivory'));}ball(0,5,0,.35,'lamp');break;
      case'Laudomia':
        for(let k=0;k<3;k++){let x0=(k-1)*11;island(x0,-1,0,5);grid(4,2.1,0,(x,z,i,j)=>{x=x*.8+x0;z=z*.8;if(k===0)box(x,.5,z,.6,1,.8,'sand');else if(k===1)house(x,0,z,1.1,2+rnd()*3,1.1);else frame(x,2,z,1.1,4,1.1,'#a4bbb1',.45);});}bridge([-11,.1,0],[11,.1,0],.65);break;
      case'Perinthia':
        for(let r=3;r<14;r+=2.8)ring(0,.1,0,r,'#a4b0b9',.55);circle(24,13,(x,z,a)=>{line([[0,.1,0],[x,.1,z]],'#b8b78e',.5);let r=3+rnd()*8;house(Math.cos(a)*r,0,Math.sin(a)*r,.8+rnd()*1.4,1+rnd()*8,.8+rnd(),'sand',false);});add('gem','gold',0,6,0,1.6,2.5,1.3);break;
      case'Procopia':
        frame(0,5,11,16,10,.4,'#ddc193',.85);for(let i=0;i<700;i++){let x=(rnd()-.5)*23,z=(rnd()-.5)*19,y=.15+rnd()*.7;ball(x,y,z,.11+rnd()*.06,i%13?'ivory':'lamp');cyl(x,y-.3,z,.09,.5,'sand');}box(0,0,11,16,.5,1,'sand');break;
      case'Raissa':
        grid(7,3.1,0,(x,z)=>house(x,0,z,1.8,1+rnd()*5,1.8,'dark',false));for(let i=0;i<12;i++){let a=i*.6;const x=Math.cos(a)*10,z=Math.sin(a)*10;curve([[x,2,z],[0,8,0],[-x,1,-z]],'#f1cf92',.9);ball(x,2,z,.16,'lamp');}break;
      case'Andria':
        circle(16,10,(x,z,a,i)=>{tower(x,z,3+(i%4),.65);ball(x,15,z,.12,'lamp');line([[x,5,z],[x,15,z]],'#b7bea9',.3);let aa=a+Math.PI*.625;line([[x,15,z],[Math.cos(aa)*10,15,Math.sin(aa)*10]],'#b4c9d0',.5);});ring(0,15,0,10,'#a7bdcf',.45);cyl(0,.3,0,5,.6,'sand');add('gem','gold',0,4,0,1.5,3,1.5);break;
      case'Cecilia':
        grid(12,2.8,0,(x,z,i,j)=>{if(Math.abs(z-Math.sin(x*.2)*5)<1)return;house(x,0,z,1.4,1.2+rnd()*3.5,1.4,'sand',false);});const p=[];for(let x=-17;x<18;x++)p.push([x,.15,Math.sin(x*.2)*5]);curve(p,'#ddbf8a',.8);break;
      case'Marozia':
        for(let i=0;i<65;i++){let x=(rnd()-.5)*23,z=(rnd()-.5)*23;box(x,1,z,rnd()>.5?2:.3,2,rnd()>.5?2:.3,'dark');}circle(16,8,(x,z,a,i)=>{let y=7+rnd()*6;line([[x-1,y,z],[x,y-.35,z+.25],[x+1,y,z]],'#e1cd9d',.85);add('cone','pale',x,y,z,.25,.8,.15,0,0,Math.PI/2);});break;
      case'Penthesilea':
        for(let i=0;i<100;i++){let a=rnd()*6.28,r=6+rnd()*9;house(Math.cos(a)*r,0,Math.sin(a)*r,1,1.3+rnd()*2,1,'sand',false);}for(let i=0;i<7;i++){let z=(i-3)*4;line([[-14,0,z],[-3,0,z+2],[5,0,z-1],[15,0,z+1]],'#b2ae91',.5);}ring(0,0,0,4,'#afbdba',.3);break;
      case'Theodora':
        grid(6,3.6,0,(x,z)=>house(x,0,z,1.8,2.3,1.8,'ivory',false));circle(15,11,(x,z,a,i)=>{add('gem','jade',x,3,z,.8,4+rnd()*4,.8);curve([[x,-2,z],[x*.7,4,z*.7],[x*.3,6,z*.3]],'#a0b49a',.7);});break;
      case'Berenice':
        for(let k=0;k<5;k++){let r=12-k*2.5;circle(32-k*5,r,(x,z,a,i)=>{let h=2+k*.5;house(x,k*.7,z,.8,h,.8,k%2?'dark':'ivory',false);});ring(0,k*.7,0,r,'#bdba95',.4);}add('gem','lamp',0,5,0,.45,1,.45);break;
    }
    // A survey ring belongs to the installation, not to the fictional city.
    if(!miniature){ring(0,-2.5,0,18,'#829a9f',.15);for(let i=0;i<72;i++){let a=i/72*Math.PI*2,r=i%6===0?18.65:18.25;line([[Math.cos(a)*18,-2.5,Math.sin(a)*18],[Math.cos(a)*r,-2.5,Math.sin(a)*r]],'#bdac8f',i%6===0?.35:.13);}}
    return b.finish();
  }
  // Atmospheric dust is a single GPU point cloud; no image assets are needed.
  const dustGeo=new T.BufferGeometry(),dustPos=[],dustColors=[];seed=31415;
  for(let i=0;i<1000;i++){dustPos.push((rnd()-.5)*230,(rnd()-.4)*110,(rnd()-.5)*230);let col=new T.Color(i%5?'#a5b6b4':'#e5c38c');dustColors.push(col.r,col.g,col.b);}
  dustGeo.setAttribute('position',new T.Float32BufferAttribute(dustPos,3));dustGeo.setAttribute('color',new T.Float32BufferAttribute(dustColors,3));
  const dust=new T.Points(dustGeo,new T.PointsMaterial({size:.075,vertexColors:true,transparent:true,opacity:.53,depthWrite:false}));scene.add(dust);
  // A soft radial halo, locally drawn rather than fetched.
  const glowCanvas=document.createElement('canvas');glowCanvas.width=glowCanvas.height=128;const gc=glowCanvas.getContext('2d');const gr=gc.createRadialGradient(64,64,0,64,64,64);gr.addColorStop(0,'rgba(112,153,157,.22)');gr.addColorStop(.45,'rgba(71,107,116,.08)');gr.addColorStop(1,'rgba(0,0,0,0)');gc.fillStyle=gr;gc.fillRect(0,0,128,128);
  const glow=new T.Sprite(new T.SpriteMaterial({map:new T.CanvasTexture(glowCanvas),transparent:true,depthWrite:false,blending:T.AdditiveBlending}));glow.scale.set(78,78,1);glow.position.set(0,2,-15);scene.add(glow);
  const atlasPositions=[];
  function makeAtlas(){
    const b=builder();seed=1222;
    for(const c of CITIES){const a=c.theme/11*Math.PI*2-.3, r=18+c.rank*8.5;const x=Math.cos(a)*r,z=Math.sin(a)*r,y=Math.sin(a*2)*3+(c.rank-3)*.8;atlasPositions[c.id]=v(x,y+2.7,z);
      const mini=city(c,true),matrix=new T.Matrix4().compose(v(x,y,z),new T.Quaternion(),v(.155,.155,.155));b.absorb(mini,matrix,c.theme);release(mini);
      b.ball(x,y+3,z,.1,'lamp');b.ring(x,y-.35,z,3.1,THEMES[c.theme][2],.65);
      const pick=new T.Mesh(new T.SphereGeometry(2.8,8,6),new T.MeshBasicMaterial({visible:false}));pick.position.set(x,y+1,z);pick.userData.city=c.id;pickables.push(pick);
    }
    for(let t=0;t<11;t++){const cs=CITIES.filter(c=>c.theme===t);b.curve(cs.map(c=>atlasPositions[c.id].toArray()),THEMES[t][2],.6);}
    // Book-order path and thematic spokes coexist, as in the novel's combinatory structure.
    for(let i=1;i<CITIES.length;i++)b.line([atlasPositions[i-1].toArray(),atlasPositions[i].toArray()],'#9aaab1',.085);
    b.ring(0,-2,0,69,'#a4b0b1',.22);b.ring(0,-2,0,12,'#b8a175',.35);b.add('gem','gold',0,1,0,1,2.4,1);
    atlas=b.finish();pickables.forEach(p=>atlas.add(p));atlas.visible=false;scene.add(atlas);
  }
  makeAtlas();
  function highlightTheme(theme){const color=new T.Color();atlas.traverse(o=>{if(o.isInstancedMesh){o.userData.themes.forEach((t,i)=>{color.setScalar(theme===null||t<0||t===theme?1:.13);o.setColorAt(i,color);});o.instanceColor.needsUpdate=true;}});}
  const pointerMap=new Map();let dragStart=null,dragged=false,pinch=0;
  canvas.addEventListener('pointerdown',e=>{canvas.setPointerCapture(e.pointerId);pointerMap.set(e.pointerId,[e.clientX,e.clientY]);dragStart=[e.clientX,e.clientY];dragged=false;if(pointerMap.size===2){const p=[...pointerMap.values()];pinch=Math.hypot(p[0][0]-p[1][0],p[0][1]-p[1][1]);}});
  canvas.addEventListener('pointermove',e=>{if(pointerMap.has(e.pointerId)){let p=pointerMap.get(e.pointerId);pointerMap.set(e.pointerId,[e.clientX,e.clientY]);if(pointerMap.size===2){const ps=[...pointerMap.values()],n=Math.hypot(ps[0][0]-ps[1][0],ps[0][1]-ps[1][1]);if(pinch)targetDist=clampDist(targetDist*pinch/Math.max(n,1));pinch=n;dragged=true;}else{az-=(e.clientX-p[0])*.006;el=Math.max(-.15,Math.min(1.4,el+(e.clientY-p[1])*.005));if(dragStart&&Math.hypot(e.clientX-dragStart[0],e.clientY-dragStart[1])>5)dragged=true;}return;}
    if(mode==='atlas'){const hit=hitTest(e);onHover(hit?hit.object.userData.city:null);canvas.style.cursor=hit?'pointer':'grab';}
  });
  function hitTest(e){const r=canvas.getBoundingClientRect();mouse.set((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1);ray.setFromCamera(mouse,camera);return ray.intersectObjects(pickables,false)[0];}
  canvas.addEventListener('pointerup',e=>{if(mode==='atlas'&&!dragged){const hit=hitTest(e);if(hit)onPick(hit.object.userData.city);}pointerMap.delete(e.pointerId);pinch=0;});
  canvas.addEventListener('pointercancel',e=>{pointerMap.delete(e.pointerId);pinch=0;});
  canvas.addEventListener('wheel',e=>{e.preventDefault();targetDist=clampDist(targetDist*Math.exp(e.deltaY*.001));},{passive:false});
  canvas.addEventListener('contextmenu',e=>e.preventDefault());
  const clampDist=d=>Math.max(mode==='atlas'?70:24,Math.min(mode==='atlas'?420:150,d));
  function resize(){const w=innerWidth,h=innerHeight;renderer.setSize(w,h,false);camera.aspect=w/h;camera.fov=w<650?50:36;camera.setViewOffset(w,h,mode==='city'&&w>800?-w*.15:0,mode==='city'&&w<=800?h*.11:0,w,h);camera.updateProjectionMatrix();}
  window.addEventListener('resize',resize);
  function select(c){currentCity=c;release(active);active=city(c);scene.add(active);active.visible=mode==='city';targetFocus=c.name==='Baucis'?8:c.name==='Thekla'?6:c.name==='Eusapia'?-1:2.5;targetDist=innerWidth<650?83:c.name==='Baucis'?82:66;cityTime=0;setWire(wire);}
  function atlasDistance(){return innerWidth<650?325:innerWidth<1000?245:220;}
  function setMode(m){mode=m;if(active)active.visible=m==='city';atlas.visible=m==='atlas';if(m==='atlas'){targetDist=atlasDistance();targetFocus=0;el=1.03;az=-.2;}else{targetDist=innerWidth<650?83:currentCity?.name==='Baucis'?82:66;targetFocus=currentCity?.name==='Baucis'?8:2.5;el=.49;az=-.58;}resize();}
  function setWire(value){wire=value;for(const [key,m]of Object.entries(M))if(m.wireframe!==undefined&&key!=='lamp'&&key!=='glass'&&key!=='water'&&key!=='dim')m.wireframe=value;}
  function setDay(value){isDay=value;scene.background.copy(value?day:night);scene.fog.color.copy(scene.background);scene.fog.density=value?.003:.004;renderer.toneMappingExposure=value?1.05:1.25;glow.visible=!value;dust.material.opacity=value?.13:.53;}
  function project(id){const p=atlasPositions[id].clone().project(camera);return{x:(p.x*.5+.5)*innerWidth,y:(-p.y*.5+.5)*innerHeight,visible:p.z<1&&p.z>0};}
  let frameHook=()=>{};
  function render(now){if(disposed)return;requestAnimationFrame(render);let dt=Math.min((now-last)/1000,.05);last=now;if(document.hidden)return;elapsed+=dt;cityTime+=dt;if(orbit&&!pointerMap.size)az+=dt*(mode==='atlas'?.013:.045);dist+=(targetDist-dist)*Math.min(1,dt*4);focus+=(targetFocus-focus)*Math.min(1,dt*4);camera.position.set(Math.sin(az)*Math.cos(el)*dist,Math.sin(el)*dist+focus,Math.cos(az)*Math.cos(el)*dist);camera.lookAt(0,focus,0);if(orbit){dust.rotation.y=elapsed*.006;if(active)active.position.y=Math.sin(elapsed*.45)*.08;}renderer.render(scene,camera);frameHook(dt);}
  resize();requestAnimationFrame(render);
  return{select,setMode,setWire,setDay,project,highlightTheme,setOrbit:v=>orbit=v,getOrbit:()=>orbit,onPick:fn=>onPick=fn,onHover:fn=>onHover=fn,onFrame:fn=>frameHook=fn,reset:()=>{az=-.58;el=mode==='atlas'?1.03:.49;targetDist=mode==='atlas'?atlasDistance():innerWidth<650?83:currentCity.name==='Baucis'?82:66;},capture:()=>{renderer.render(scene,camera);return canvas;},getStats:()=>({drawCalls:renderer.info.render.calls,triangles:renderer.info.render.triangles,geometries:renderer.info.memory.geometries}),destroy:()=>{disposed=true;release(active);release(atlas);renderer.dispose();}};
}
